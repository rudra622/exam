import React from 'react'

function Buyproduct() {
  return (
    <div>Buyproduct</div>
  )
}

export default Buyproduct