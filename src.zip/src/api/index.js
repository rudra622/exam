import axios from "axios";
import { BASEURL } from "./BASEURL";

export const Api =axios.create({
    baseURL : BASEURL
})  







