import { combineReducers } from "redux";

import productReducer from "../Reducer/ProductReducer";

const rootReducer = combineReducers ({
    productReducer
})

export default rootReducer;